Action()
{

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_set_user("USER_CLIENT_APP", 
		lr_unmask("63cbb6b9882f2bffdf913872"), 
		"www.ishatrainingsolutions.com:443");

	web_add_auto_header("Sec-Fetch-Dest", 
		"document");

	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_auto_header("Sec-Fetch-Site", 
		"none");

	web_add_auto_header("DNT", 
		"1");

	web_add_header("Sec-Fetch-User", 
		"?1");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("www.ishatrainingsolutions.com", 
		"URL=https://www.ishatrainingsolutions.com/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t22.inf", 
		"Mode=HTML", 
		LAST);

	web_set_sockets_option("INITIAL_AUTH", "BASIC");

	web_websocket_send("ID=0", 
		"Buffer={\"messageType\":\"hello\",\"broadcasts\":{\"remote-settings/monitor_changes\":\"\\\"1674291430417\\\"\"},\"use_webpush\":true}", 
		"IsBinary=0", 
		LAST);

	/*Connection ID 0 received buffer WebSocketReceive0*/

	lr_start_transaction("Login");

	/*Possible OAUTH authorization was detected. It is recommended to correlate the authorization parameters.*/

	web_add_header("Origin", 
		"https://www.ishatrainingsolutions.com");

	web_add_auto_header("Sec-Fetch-Dest", 
		"empty");

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	lr_think_time(11);

	web_custom_request("token", 
		"URL=https://www.ishatrainingsolutions.com/oauth/token?grant_type=password&username=ishatrainingsolution&password=ishatrainingsolution", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://www.ishatrainingsolutions.com/login?returnUrl=%2Fvalidate", 
		"Snapshot=t23.inf", 
		"Mode=HTML", 
		"EncType=", 
		LAST);

	web_url("secQue", 
		"URL=https://www.ishatrainingsolutions.com/adminPortal/secQue", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://www.ishatrainingsolutions.com/validate", 
		"Snapshot=t24.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("Login",LR_AUTO);

	lr_start_transaction("Security_Question");

	web_add_header("Origin", 
		"https://www.ishatrainingsolutions.com");

	lr_think_time(38);

	web_custom_request("secVal", 
		"URL=https://www.ishatrainingsolutions.com/adminPortal/secVal", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://www.ishatrainingsolutions.com/validate", 
		"Snapshot=t25.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"id\":2,\"question\":\"Which is Your Country\",\"answer\":\"india\"}", 
		LAST);

	lr_end_transaction("Security_Question",LR_AUTO);

	lr_think_time(46);

	lr_start_transaction("Navigate_MerchantTab");

	web_url("getAllLanguages", 
		"URL=https://www.ishatrainingsolutions.com/adminPortal/getAllLanguages", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://www.ishatrainingsolutions.com/merchants", 
		"Snapshot=t26.inf", 
		"Mode=HTML", 
		LAST);

	web_url("getAllStatus", 
		"URL=https://www.ishatrainingsolutions.com/adminPortal/getAllStatus", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://www.ishatrainingsolutions.com/merchants", 
		"Snapshot=t27.inf", 
		"Mode=HTML", 
		LAST);

	web_url("4", 
		"URL=https://www.ishatrainingsolutions.com/adminPortal/getHolderType/4", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://www.ishatrainingsolutions.com/merchants", 
		"Snapshot=t28.inf", 
		"Mode=HTML", 
		LAST);

	web_url("getAllType", 
		"URL=https://www.ishatrainingsolutions.com/adminPortal/getAllType", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://www.ishatrainingsolutions.com/merchants", 
		"Snapshot=t29.inf", 
		"Mode=HTML", 
		LAST);

	web_url("getAllPortalVersion", 
		"URL=https://www.ishatrainingsolutions.com/adminPortal/getAllPortalVersion", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://www.ishatrainingsolutions.com/merchants", 
		"Snapshot=t30.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("Navigate_MerchantTab",LR_AUTO);

	lr_think_time(133);

	lr_start_transaction("Save_Merchant");

	web_url("genReference", 
		"URL=https://www.ishatrainingsolutions.com/adminPortal/genReference", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://www.ishatrainingsolutions.com/merchants", 
		"Snapshot=t31.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("Save_Merchant",LR_AUTO);

	lr_start_transaction("Click_Process");

	web_add_auto_header("Origin", 
		"https://www.ishatrainingsolutions.com");

	web_custom_request("registerMerchant", 
		"URL=https://www.ishatrainingsolutions.com/adminPortal/registerMerchant", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://www.ishatrainingsolutions.com/merchants", 
		"Snapshot=t32.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"msisdn\":\"2023012155301\",\"name\":\"Capslock\",\"emailAddress\":\"capslock@abc.com\",\"language\":\"English\",\"protocolVersion\":\"\",\"serviceUri\":\"\",\"walletStatus\":\"1\",\"dfsWalletBank\":[{\"bankwalletid\":\"154\",\"bankAccount\":\"1234567891\",\"bankAccountHashCode\":null,\"walletBankId\":null}],\"dfsRegisterAgent\":{\"companyName\":\"Capslock\",\"alternativeEmailAddress1\":\"\",\"alternativeEmailAddress2\":\"\",\"smsAddress\":\"\",\"kvkId\":\"\",\"contactNo\":\"\",\"locality\""
		":\"Bengaluru-South\",\"companyAddress\":\"\",\"type_id\":\"1\",\"registerAgentId\":\"\"},\"dfsProfilePictureDto\":{\"profilePicture\":\"\"},\"walletId\":\"\",\"file\":\"\",\"date\":\"2023-01-21T09:49:39.768Z\"}", 
		LAST);

	web_submit_data("2023012155301", 
		"Action=https://www.ishatrainingsolutions.com/adminPortal/merchantVal/2023012155301", 
		"Method=POST", 
		"EncType=multipart/form-data", 
		"RecContentType=application/json", 
		"Referer=https://www.ishatrainingsolutions.com/merchants", 
		"Snapshot=t33.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=token", "Value=pnjhes+jDK4fYUYy4RdE4w==", ENDITEM, 
		"Name=file", "Value=", ENDITEM, 
		LAST);

	lr_end_transaction("Click_Process",LR_AUTO);

	lr_think_time(106);

	lr_start_transaction("Search_Merchants");

	web_custom_request("showDetails", 
		"URL=https://www.ishatrainingsolutions.com/adminPortal/showDetails?value=capslock", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://www.ishatrainingsolutions.com/", 
		"Snapshot=t34.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body=[1,2,3,4,5,6]", 
		LAST);

	web_revert_auto_header("Origin");

	lr_think_time(200);

	web_url("getWallet", 
		"URL=https://www.ishatrainingsolutions.com/adminPortal/getWallet?value=2022081797091", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://www.ishatrainingsolutions.com/", 
		"Snapshot=t35.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("Search_Merchants",LR_AUTO);

	return 0;
}