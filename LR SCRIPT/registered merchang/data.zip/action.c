Action()
{

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_set_user("USER_CLIENT_APP", 
		lr_unmask("63c948b5aeb98965026cd098"), 
		"www.ishatrainingsolutions.com:443");

	web_add_auto_header("Sec-Fetch-Dest", 
		"document");

	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_auto_header("Sec-Fetch-Site", 
		"none");

	web_add_auto_header("DNT", 
		"1");

	web_add_header("Sec-Fetch-User", 
		"?1");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("www.ishatrainingsolutions.com", 
		"URL=https://www.ishatrainingsolutions.com/", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		LAST);

	web_set_sockets_option("INITIAL_AUTH", "BASIC");

	/*Possible OAUTH authorization was detected. It is recommended to correlate the authorization parameters.*/

	web_add_header("Origin", 
		"https://www.ishatrainingsolutions.com");

	web_add_auto_header("Sec-Fetch-Dest", 
		"empty");

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	web_custom_request("token", 
		"URL=https://www.ishatrainingsolutions.com/oauth/token?grant_type=password&username=ishatrainingsolution&password=ishatrainingsolution", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://www.ishatrainingsolutions.com/login?returnUrl=%2Fvalidate", 
		"Snapshot=t9.inf", 
		"Mode=HTML", 
		"EncType=", 
		LAST);

	web_url("secQue", 
		"URL=https://www.ishatrainingsolutions.com/adminPortal/secQue", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://www.ishatrainingsolutions.com/validate", 
		"Snapshot=t10.inf", 
		"Mode=HTML", 
		LAST);

	lr_start_transaction("login");

	web_url("secQue_2", 
		"URL=https://www.ishatrainingsolutions.com/adminPortal/secQue", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://www.ishatrainingsolutions.com/validate", 
		"Snapshot=t11.inf", 
		"Mode=HTML", 
		LAST);

	web_url("secQue_3", 
		"URL=https://www.ishatrainingsolutions.com/adminPortal/secQue", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://www.ishatrainingsolutions.com/validate", 
		"Snapshot=t12.inf", 
		"Mode=HTML", 
		LAST);

	web_url("secQue_4", 
		"URL=https://www.ishatrainingsolutions.com/adminPortal/secQue", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://www.ishatrainingsolutions.com/validate", 
		"Snapshot=t13.inf", 
		"Mode=HTML", 
		LAST);

	return 0;
}