Action()
{

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_add_auto_header("Sec-Fetch-Dest", 
		"document");

	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_auto_header("Sec-Fetch-Site", 
		"none");

	web_add_auto_header("DNT", 
		"1");

	web_add_auto_header("Sec-Fetch-User", 
		"?1");

	web_add_auto_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("computers", 
		"URL=https://computer-database.gatling.io/computers", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		LAST);

	lr_start_transaction("Pagination 1");

	web_revert_auto_header("Sec-Fetch-User");

	web_revert_auto_header("Upgrade-Insecure-Requests");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	lr_think_time(6);

	web_url("Next →", 
		"URL=https://computer-database.gatling.io/computers?p=1&n=10&s=name&d=asc", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://computer-database.gatling.io/computers", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		LAST);

	lr_start_transaction("Pagination 2");

	web_add_header("Sec-Fetch-User", 
		"?1");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("Next →_2", 
		"URL=https://computer-database.gatling.io/computers?p=2&n=10&s=name&d=asc", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://computer-database.gatling.io/computers?p=1&n=10&s=name&d=asc", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		LAST);

	lr_start_transaction("Search Computers");

	lr_end_transaction("Search Computers",LR_AUTO);

	lr_start_transaction("Clic_computer");

	lr_end_transaction("Clic_computer",LR_AUTO);

	lr_start_transaction("save computer");

	lr_end_transaction("save computer",LR_AUTO);

	return 0;
}